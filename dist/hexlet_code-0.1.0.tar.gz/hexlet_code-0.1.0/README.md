### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nea1o/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Nea1o/python-project-49/actions)
[![Code Climate](https://camo.githubusercontent.com/13fac8fbe2bfb7af717785f6c9ff0bf089d5033bc4b86e955d0f61bbf40b52d4/68747470733a2f2f636f6465636c696d6174652e636f6d2f6769746875622f636c6f7564666f756e6472792f6d656d6272616e652e706e67)](https://codeclimate.com/github/Nea1o/python-project-49)
[![Static Badge](https://img.shields.io/badge/records-brain_even-blue)](https://asciinema.org/a/3HijhIAPJCQAEZhfd2LzgjZXD)
[![Static Badge](https://img.shields.io/badge/records-brain_calc-blue)](https://asciinema.org/a/8CgESU1MCkJjnm8qJi8YQIJwx)
[![Static Badge](https://img.shields.io/badge/records-brain_gcd-blue)](https://asciinema.org/a/NAvMdoHm27T7XBxHJXNsAnYbZ)